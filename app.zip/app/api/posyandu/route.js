// app/api/posyandu/route.js
import { NextResponse } from "next/server";
import { generateMockPosyandu } from "@/lib/mockData";
// import { getPosyanduData } from "@/lib/sheets"; // pakai ini begitu Sheets asli siap

// revalidate: cache selama 60 detik di edge, biar nggak nembak sumber data
// (nanti: Google Sheets API) tiap kali ada yang buka dashboard — ini yang
// jaga supaya tetap ringan & nggak boros kuota di skala provinsi.
export const revalidate = 60;

export async function GET() {
  const data = generateMockPosyandu(); // ganti: await getPosyanduData()
  return NextResponse.json({ data, syncedAt: new Date().toISOString() });
}
