// app/api/kader/route.js
import { NextResponse } from "next/server";
import { generateMockPosyandu, generateMockKader } from "@/lib/mockData";
// import { getKaderData } from "@/lib/sheets"; // pakai ini begitu Sheets asli siap

export const revalidate = 60;

export async function GET() {
  const posyandu = generateMockPosyandu();
  const data = generateMockKader(posyandu); // ganti: await getKaderData()
  return NextResponse.json({ data, syncedAt: new Date().toISOString() });
}
